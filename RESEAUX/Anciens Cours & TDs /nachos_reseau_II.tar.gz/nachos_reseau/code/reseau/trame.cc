// trame.cc 

#include "copyright.h"
#include "trame.h"

#include <strings.h>

Trame::Trame (TypeTrame type, char *user_data, unsigned user_len)
{
  header.type = type;
  bcopy (user_data, data, user_len);
  header.len = user_len;
}
