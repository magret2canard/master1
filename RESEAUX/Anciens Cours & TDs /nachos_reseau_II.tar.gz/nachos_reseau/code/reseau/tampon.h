// tampon.h

#include "copyright.h"

#ifndef TAMPON_H
#define TAMPON_H

#include "synch.h"
#include "trame.h"

class Tampon
{
public:
  Tampon (unsigned taille);
  ~Tampon ();

  const unsigned taille_max;

  unsigned NbTrames (void);

  void Ajouter (Trame *);

  int TenterAjout (Trame *);

  Trame *Retirer (void);

  Trame *TrameNumero (unsigned);

private:
    Trame ** buffer;
  Semaphore *cons;
  Semaphore *prod;
  Lock *mutex;

  unsigned nbtr, index_cons, index_prod;
};

#endif
