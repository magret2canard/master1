// trame.h

#include "copyright.h"

#ifndef TRAME_H
#define TRAME_H

#include "network.h"

typedef enum
{
  Trame_INFO,
  Trame_ACK,
  Trame_REJECT
}
TypeTrame;

class TrameHeader
{
public:
  unsigned len;			// taille du champ de donn�es
  TypeTrame type;		// type (info, ack, reject, etc.)
  unsigned NS;			// num�ro de trame (�mission)
  unsigned NR;			// num�ro de trame (acquittement/rejet)
  unsigned DebugInfo;           // exclusivement reserv� au debugage 
};  

class Trame
{
public:
  Trame (TypeTrame type, char *user_data = NULL, unsigned user_len = 0);
  TrameHeader header;
  char data[MaxPacketSize - sizeof (TrameHeader)];	// donn�es
};

#endif
