// tampon.cc 

#include "copyright.h"
#include "tampon.h"

#include <strings.h>

Tampon::Tampon (unsigned taille):
taille_max (taille)
{
  buffer = new Trame *[taille];
  nbtr = 0;
  index_cons = 0;
  index_prod = 0;

  cons = new Semaphore ((char *)"consommer", 0);
  prod = new Semaphore ((char *)"produire", taille);
  mutex = new Lock ((char *)"mutex");
}

Tampon::~Tampon ()
{
  delete[]buffer;
  delete cons;
  delete prod;
  delete mutex;
}

unsigned
Tampon::NbTrames (void)
{
  unsigned n;

  mutex->Acquire ();
  n = nbtr;
  mutex->Release ();

  return n;
}

void
Tampon::Ajouter (Trame * trame)
{
  prod->P ();

  mutex->Acquire ();
  buffer[index_prod] = trame;
  index_prod = (index_prod + 1) % taille_max;
  nbtr++;
  mutex->Release ();

  cons->V ();
}

int
Tampon::TenterAjout (Trame * trame)
{
  if(prod->Try_P () == -1)
    return -1;

  mutex->Acquire ();
  buffer[index_prod] = trame;
  index_prod = (index_prod + 1) % taille_max;
  nbtr++;
  mutex->Release ();

  cons->V ();

  return 0;
}

Trame *
Tampon::Retirer (void)
{
  Trame *trame;

  cons->P ();

  mutex->Acquire ();
  trame = buffer[index_cons];
  index_cons = (index_cons + 1) % taille_max;
  nbtr--;
  mutex->Release ();

  prod->V ();

  return trame;
}

Trame *
Tampon::TrameNumero (unsigned num)
{
  return buffer[num % taille_max];
}
