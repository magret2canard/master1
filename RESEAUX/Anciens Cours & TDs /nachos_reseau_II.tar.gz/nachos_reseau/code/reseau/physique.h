// physique.h

#include "copyright.h"

#ifndef PHYSIQUE_H
#define PHYSIQUE_H

#include "network.h"
#include "trame.h"

#include "synchlist.h"

class CouchePhysique
{
public:
  CouchePhysique (NetworkAddress addr, double reliability);
  //   "reliability" is how many packets
  //   get dropped by the underlying network
   ~CouchePhysique ();

  void EnvoyerTrame (Trame * t);

  Trame *RecevoirTrame (void);

  void TrameEmise ();		// Interrupt handler, called when outgoing 
  // packet has been put on network; next 
  // packet can now be sent
  void TrameRecue ();		// Interrupt handler, called when incoming
  // packet has arrived and can be pulled
  // off of network (i.e., time to call 
  // PostalDelivery)

  NetworkAddress GetNetAddress (void)
  {
    return netAddr;
  }

private:

    Network * network;		// Physical network connection
  NetworkAddress netAddr;	// Network address of this machine
  NetworkAddress peerAddr;	// Network address of the peer machine
  Semaphore *messageAvailable;	// V'ed when message has arrived from network
  Semaphore *messageSent;	// V'ed when next message can be sent to network
  Lock *sendLock;		// Only one outgoing message at a time
};

#endif
