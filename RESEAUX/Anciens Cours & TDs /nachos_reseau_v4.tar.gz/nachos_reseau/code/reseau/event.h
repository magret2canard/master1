// event.h

#include "copyright.h"

#ifndef EVENT_H
#define EVENT_H

#include "synchlist.h"

typedef enum
{
  Event_NEW_FRAME,
  Event_ACK_RECEIVED,
  Event_REJECT_RECEIVED,
  Event_TIMER_EXPIRATION
}
TypeEvent;

class Evenement
{
public:
  Evenement (TypeEvent t, unsigned trame = 0)
  {
    type = t;
    num = trame;
  }
  TypeEvent type;		// type de l'�v�nement
  unsigned num;			// num�ro de trame concern�e (le cas �ch�ant)

  void Print (void);
};

class ListeEvenements
{
public:
  ListeEvenements ();
  ~ListeEvenements ();

  void Generer (Evenement * e);
  Evenement *Recuperer ();

private:
    SynchList * events;
};

#endif
