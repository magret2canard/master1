// temporisateur.h

#include "copyright.h"

#ifndef TEMPORISATEUR_H
#define TEMPORISATEUR_H

#include "interrupt.h"
#include "event.h"
#include "synchlist.h"

#define TEMPO_ACQUITTEMENT  500000

typedef enum
{
  Expiration_ACK
}
TypeAlarme;

class Temporisateur
{
public:
  Temporisateur ();
  ~Temporisateur ();

  void Armer (unsigned delai,
	      TypeAlarme type, unsigned num, ListeEvenements * liste);

  // a usage interne :
  void Declencher (void);

  Semaphore *top;

private:
    SynchList * alarmes;
};

#endif
