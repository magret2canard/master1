// liaison.h

#include "copyright.h"

#ifndef LIAISON_H
#define LIAISON_H

#include "network.h"
#include "trame.h"
#include "tampon.h"
#include "physique.h"
#include "event.h"
#include "temporisateur.h"

class CoucheLiaison
{
public:
  CoucheLiaison (NetworkAddress addr, double reliability);
  //   "reliability" is how many packets
  //   get dropped by the underlying network
   ~CoucheLiaison ();

  void EnvoyerPaquet (char *data, unsigned len);

  void RecevoirPaquet (char *data, unsigned *len);

  void ProtocoleEmission (void);

  void ProtocoleReception (void);

  void DemonReception (void);

  NetworkAddress GetNetAddress (void)
  {
    return couchePhysique->GetNetAddress ();
  }

private:
  void Emettre(unsigned trame_courante);

  CouchePhysique * couchePhysique;
  
  Tampon *tamponEmission, *tamponReception, *tamponDemon;

  ListeEvenements evtEmission, evtReception;

  Temporisateur *temporisateur;
};

#endif
