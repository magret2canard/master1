// event.cc 

#include "copyright.h"
#include "event.h"

void
Evenement::Print (void)
{
  switch (type)
    {
    case Event_NEW_FRAME:
      printf ("Event NEW_FRAME\n");
      break;
    case Event_ACK_RECEIVED:
      printf ("Event ACK\n");
      break;
    case Event_REJECT_RECEIVED:
      printf ("Event REJECT\n");
      break;
    case Event_TIMER_EXPIRATION:
      printf ("Event TIMER_EXPIRATION\n");
      break;
    default:
      printf ("Unknown event\n");
    }
}

ListeEvenements::ListeEvenements ()
{
  events = new SynchList ();
}

ListeEvenements::~ListeEvenements ()
{
  delete events;
}

void
ListeEvenements::Generer (Evenement * e)
{
  events->Append ((void *) e);
}

Evenement *
ListeEvenements::Recuperer ()
{
  return (Evenement *) events->Remove ();
}
