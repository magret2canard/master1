// liaison.cc 

#include "copyright.h"
#include "liaison.h"
#include "system.h"
#include <unistd.h>

#include <strings.h>

// Les 3 fonctions suivantes servent juste � rediriger l'ex�cution des
// Threads correspondants vers les bonnes fonctions C++...

static void
ProtocoleReception_Root (int arg)
{
  ((CoucheLiaison *) arg)->ProtocoleReception ();
}

static void
ProtocoleEmission_Root (int arg)
{
  sleep(3);
  ((CoucheLiaison *) arg)->ProtocoleEmission ();
}

static void
DemonReception_Root (int arg)
{
  ((CoucheLiaison *) arg)->DemonReception ();
}


CoucheLiaison::CoucheLiaison (NetworkAddress addr, double reliability)
{
  Thread *tr, *ts, *tf;

  couchePhysique = new CouchePhysique (addr, reliability);

  tamponReception = new Tampon (1);
  tamponEmission = new Tampon (5);
  tamponDemon = new Tampon (1);

  temporisateur = new Temporisateur;

  tr = new Thread ((char *)"protocole de reception");
  tr->Fork (ProtocoleReception_Root, (int) this);

  ts = new Thread ((char *)"protocole d'�mission");
  ts->Fork (ProtocoleEmission_Root, (int) this);

  tf = new Thread ((char *)"demon de r�ception");
  tf->Fork (DemonReception_Root, (int) this);
}

CoucheLiaison::~CoucheLiaison ()
{
  delete couchePhysique;
  delete tamponReception;
  delete tamponEmission;
  delete temporisateur;
}

void
CoucheLiaison::EnvoyerPaquet (char *data, unsigned len)
{
  Trame *trame = new Trame (Trame_INFO, data, len);

  tamponEmission->Ajouter (trame);
  evtEmission.Generer (new Evenement (Event_NEW_FRAME));
}

void
CoucheLiaison::RecevoirPaquet (char *data, unsigned *len)
{
  Trame *trame;

  trame = tamponReception->Retirer ();

  bcopy (trame->data, data, trame->header.len);
  *len = trame->header.len;

  delete trame;
}

void
CoucheLiaison::Emettre (unsigned trame_courante)
{
  Trame *trame;

  // On r�cup�re la trame du tampon d'�mission
  trame = tamponEmission->TrameNumero (trame_courante);

  trame->header.DebugInfo = trame_courante; // inutile au protocole

  // On l'envoie sur le r�seau
  DEBUG ('l', (char *)"\t [E] Emission de la trame %d\n", trame_courante);
  couchePhysique->EnvoyerTrame (trame);

  temporisateur->Armer (1 * TEMPO_ACQUITTEMENT, Expiration_ACK,
			trame_courante, &evtEmission);
}

void
CoucheLiaison::ProtocoleEmission ()
{

  Evenement *evt;
  unsigned ack_recu = TRUE;	// A-t-on re�u l'acquittement pour la
                                // trame courante?
  unsigned trame_courante = 0;	// num�ro de s�quence � usage local
  unsigned a_emettre = 0;	// nombre de trames potentiellement
                                // transmissibles

  for (;;)
    {

      evt = evtEmission.Recuperer ();	// On attend le prochain
                                        // �v�nement
      switch (evt->type)
	{

	case Event_NEW_FRAME:
	  {
	    // La couche sup�rieure a d�pos� une trame suppl�mentaire
	    // � �mettre

	    if (ack_recu)
	      {
		// on emet que si la trame pr�c�dente a �t� acquitt�e
		Emettre (trame_courante);
		ack_recu = FALSE;
	      }
	    else
	      {
		// On met � jour le nombre de trames que l'on pourra
		// �mettre plus tard
		a_emettre++;
	      }

	    break;
	  }

	case Event_ACK_RECEIVED:
	  {
	    
	    Trame *trame_ack = tamponDemon->Retirer ();
	    
	    // On re�oit un acquittement
	    ack_recu = TRUE;
	    
	    DEBUG ('l', (char *)"\t [E] Acquittement re�u pour la trame %d\n",
		   trame_courante);
	    
	    trame_courante++;
	    
	    // On peut retirer la trame �mise du tampon et la
	    // d�truire...
	    
	    delete tamponEmission->Retirer ();
	    
	    // Il faut maintenant regarder s'il reste des trames �
	    // �mettre
	    
	    if (a_emettre)
	      {
		Emettre (trame_courante);
		ack_recu = FALSE;
		a_emettre--;
	      }
	    break;
	  }
	  
	case Event_TIMER_EXPIRATION:
	  {
	    // expiration d'un temporisateur
	    
	    if (!ack_recu && evt->num == trame_courante)
	      {		
		DEBUG ('l',
		       (char *)"\t [E] Expiration du temporisateur pour la trame %d\n",
		       evt->num);
		
		// Il faut r�-�mettre la trame courante
		Emettre (trame_courante);
	      }
	    
	    break;
	  }
	  
	default:
	  {
	    fprintf (stderr, "Oups: �v�nement inattendu en �mission !\n");
	    interrupt->Halt ();
	  }
	}			// switch
      
      delete evt;
    }
}

void
CoucheLiaison::ProtocoleReception ()
{
  Evenement *evt;
  unsigned numero_attendu = 0;
  
  for (;;)
    {
      
      // On attend le prochain �v�nement
      evt = evtReception.Recuperer ();
      
      switch (evt->type)
	{
	  
	case Event_NEW_FRAME:
	  {
	    
	    Trame *trame_ack = new Trame (Trame_ACK);
	    Trame *trame_recue = tamponDemon->Retirer ();

	    trame_ack->header.DebugInfo = trame_recue->header.DebugInfo;
	    	    
	    tamponReception->Ajouter (trame_recue);
	    numero_attendu++;
	    	    
	    DEBUG ('l', (char *)"\t [R] Emission d'un ack (trame %d)\n",
		   trame_ack->header.DebugInfo);
	    couchePhysique->EnvoyerTrame (trame_ack);
	    break;
	  }
	  
	default:
	  {
	    fprintf (stderr, "Oups: �v�nement inattendu en r�ception !\n");
	    interrupt->Halt ();
	  }
	  
	}
      
      delete evt;
    }
}

void
CoucheLiaison::DemonReception ()
{

  for (;;)
    {

      Trame *trame = couchePhysique->RecevoirTrame ();
      tamponDemon->Ajouter (trame);

      switch (trame->header.type)
	{
	case Trame_INFO:
	  {

	    DEBUG ('l', (char *)"\t [D] R�ception de la trame %d \n",
		   trame->header.DebugInfo);

	    evtReception.
	      Generer (new Evenement (Event_NEW_FRAME));

	    break;
	  }
	case Trame_ACK:
	  {
	    DEBUG ('l', (char *)"\t [D] R�ception d'un ack (trame %d) \n",
		    trame->header.DebugInfo);

	    // On signale l'�v�nement au d�mon de r�ception
	    evtEmission.
	      Generer (new Evenement (Event_ACK_RECEIVED));
	    break;
	  }

	case Trame_REJECT:
	  {
	    ASSERT (FALSE);
	    break;
	  }

	default:
	  {
	    fprintf (stderr, "Oups: trame de type inconnu re�ue !\n");
	    interrupt->Halt ();
	  }
	}			// switch
            
    }				// for
}
