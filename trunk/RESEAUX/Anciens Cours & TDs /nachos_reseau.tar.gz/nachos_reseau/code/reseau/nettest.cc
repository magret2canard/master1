// nettest.cc
//
//      Test de la couche "liaison" �tablie entre deux machines Nachos
//
//      Il faut donc lancer deux processus Nachos quasi-simultan�ment,
//      de pr�f�rence dans deux fen�tres diff�rentes.
//
//      # Dans la premi�re fen�tre :
//      ./nachos -m 0
//
//      # Dans la seconde fen�tre :
//      ./nachos -m 1
//
//      Pour introduire des pertes de paquets, il suffit d'utiliser
//      l'option '-l <taux>' qui permet de sp�cifier le taux de
//      fiabilit� de la ligne _en_�mission_. Voici par exemple comment
//      mettre en place une liaison perdant environ 50% de ses paquets
//      de m0 vers m1 et 10% dans l'autre sens :
//
//      ./nachos -m 0 -l 0.5
//
//      ./nachos -m 1 -l 0.9
//
//      Notez enfin que l'option '-d n' permet l'affichage des
//      messages de "debug" relatifs au r�seau...
//

#include "copyright.h"

#include "system.h"
#include "liaison.h"

#define NB_PAQUETS  10

void
NetTest (void)
{
  char data[1024] = "Hello there from!";
  char buffer[MaxPacketSize];
  unsigned i, len, self;

  printf ("*** D�but du main\n");

  self = coucheLiaison->GetNetAddress ();

  if (self == 0)
    {				// machine 0

      for (i = 0; i < NB_PAQUETS; i++)
	{

	  sprintf (data, "Hello from %d (paquet %d)", self, i);

	  // Emission
	  printf ("J'ai tent� d'�mettre le paquet <%s>\n", data);
	  coucheLiaison->EnvoyerPaquet (data, strlen (data) + 1);
	}

    }
  else
    {				// machine 1

      for (i = 0; /* i < NB_PAQUETS */ ; i++)
	{

	  // Reception
	  coucheLiaison->RecevoirPaquet (buffer, &len);
	  printf ("J'ai re�u le paquet <%s>\n", buffer);
	}

    }

  printf ("*** Fin du main\n");
}
