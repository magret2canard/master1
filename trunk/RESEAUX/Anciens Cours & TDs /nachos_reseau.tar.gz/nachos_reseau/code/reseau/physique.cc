// physique.cc 

#include "copyright.h"
#include "physique.h"

#include <strings.h>		/* for bzero */

static void
ReadAvail (int arg)
{
  CouchePhysique *phys = (CouchePhysique *) arg;
  phys->TrameRecue ();
}
static void
WriteDone (int arg)
{
  CouchePhysique *phys = (CouchePhysique *) arg;
  phys->TrameEmise ();
}

CouchePhysique::CouchePhysique (NetworkAddress addr, double reliability)
{
  messageAvailable = new Semaphore ((char *)"message available", 0);
  messageSent = new Semaphore ((char *)"message sent", 0);
  sendLock = new Lock ((char *)"message send lock");

  ASSERT (addr == 0 || addr == 1);

  netAddr = addr;
  peerAddr = 1 - addr;

  network = new Network (addr, reliability, ReadAvail, WriteDone, (int) this);
}

CouchePhysique::~CouchePhysique ()
{
  delete network;
  delete messageAvailable;
  delete messageSent;
  delete sendLock;
}

void
CouchePhysique::EnvoyerTrame (Trame * t)
{
  PacketHeader pktHdr;

  pktHdr.from = netAddr;
  pktHdr.to = peerAddr;
  pktHdr.length = sizeof (Trame);

  sendLock->Acquire ();		// only one message can be sent
  // to the network at any one time
  network->Send (pktHdr, (char *) t);
  messageSent->P ();		// wait for interrupt to tell us
  // ok to send the next message
  sendLock->Release ();
}

Trame *
CouchePhysique::RecevoirTrame (void)
{
  PacketHeader pktHdr;
  Trame *t = new Trame (Trame_INFO);

  messageAvailable->P ();
  pktHdr = network->Receive ((char *) t);

  ASSERT (pktHdr.length == sizeof (Trame));

  return t;
}

void
CouchePhysique::TrameRecue ()
{
  messageAvailable->V ();
}

void
CouchePhysique::TrameEmise ()
{
  messageSent->V ();
}
