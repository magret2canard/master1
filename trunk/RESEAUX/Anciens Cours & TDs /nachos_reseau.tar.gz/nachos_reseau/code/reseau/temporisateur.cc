// temporisateur.cc 

#include "copyright.h"
#include "temporisateur.h"
#include "event.h"
#include "system.h"

class Alarme
{
public:
  TypeAlarme type;
  unsigned num;			// trame concern�e
  ListeEvenements *liste;
};

static void
expiration_timer (int arg)
{
  ((Temporisateur *) arg)->top->V ();
}

static void
demon_alarme (int arg)
{
  ((Temporisateur *) arg)->Declencher ();
}

Temporisateur::Temporisateur ()
{
  Thread *t;

  alarmes = new SynchList ();

  top = new Semaphore ((char *)"top alarme", 0);

  t = new Thread ((char *)"demon de temporisation");
  t->Fork (demon_alarme, (int) this);
}

Temporisateur::~Temporisateur ()
{
  delete alarmes;
  delete top;
}

void
Temporisateur::Armer (unsigned delai,
		      TypeAlarme type, unsigned num, ListeEvenements * liste)
{
  Alarme *alarme = new Alarme;

  alarme->type = type;
  alarme->num = num;
  alarme->liste = liste;

  alarmes->Append ((void *) alarme);

  interrupt->Schedule (expiration_timer, (int) this, delai, TimerInt);
}

void
Temporisateur::Declencher (void)
{
  Alarme *alarme;

  for (;;)
    {

      // attendre une alarme
      top->P ();

      alarme = (Alarme *) alarmes->Remove ();

      switch (alarme->type)
	{

	case Expiration_ACK:
	  {
	    alarme->liste->
	      Generer (new Evenement (Event_TIMER_EXPIRATION, alarme->num));
	    break;
	  }

	default:
	  {
	    fprintf (stderr, "Oups: type d'alarme inattendu !\n");
	    interrupt->Halt ();
	  }

	}

      delete alarme;
    }
}
